

//function declaration

// console.log(square(5))
// function square(num){
//     return num * num
// }

//function expressions

//named function expression
// const square = function sqr(num){
//     return  num * num
// }
// console.log(square(5))

//unnamed function expression


// console.log(square(5))
// const square = function (num){
//     return  num * num
// }


//anonymous function
//can be used in function exprestion, you can also return it
//and it can also be passed inside a function

// function x(){
//     let a = 10
//     return function (){
//         console.log(10)
//     }
// }
// x()()


// function x(callback){
//     console.log('hi')
//     callback()
// }


// x(function (){
//     console.log('bye')
// })


//arrow function

// let double = function (number){
//     return number * 2
// }

// let double = number =>  number * 2

// console.log(double(2))