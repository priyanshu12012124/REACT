

//function declaration

// function greetings() {
//     alert('hey everyone')
// }
// greetings()
// greetings()

// function sum(num1, num2) {

//     return num1 + num2
// }
// console.log(sum(10, 20))


//what is javascript
//js is a syncronous single threaded language

//synchronous => line by line
//single threaded =>beginninh to end or top to down


//let const and var

// let a = 20
// var b = 30
// const c = 40

//variable using const cannot be reassigned
// a = 40
// b = 60

// console.log(a, b)

//you cannot redeclare the variable 
//using let and const  in the same scope
// let a = 40
// var b = 60
// console.log(b)



//var is a function scope 
//and let and const are blocked scope

// var a = 10

// function x() {
//     var a = 20
//     console.log(a)
// }
// console.log(a)
// x()


//=> {}

// var a = 10

// {
//     var a = 20
//     console.log(a)
// }
// console.log(a)

// let a = 10

// {
//     let a = 20
//     console.log(a)
// }
// console.log(a)


// let a = 10

// function x() {
//     let a = 20
//     console.log(a)
// }
// x()
// console.log(a)

//you can access a variable created using var in case of let and const 
//you cannot access the variable before initialization

//before even initializing it
// console.log(a)
// var a = 10

// console.log(a)
// let a = 10




