//single line comment
//intro to js
// js was create to make web pages alive (interactivity)
//script => program in js
//write js in html and it runs as the page loads
//js specification is ECMAScript
//browser, server, mobiles or any devices that has javascript engine (special program)
//Different js engines have diff names
//V8 - in Chrome, Opera, Edge
//SpiderMonkey - firefox
//chakra, nitro

/* multi
line
comment
 */

// console.log('hi everyone')

//variables
//variable is named storage


//to create a variable in js use
//let keyword

//declare a variable
// let message;

// //initialize
// message = 'Hello world'
// // message = 20

// console.log(typeof message)

// let age = prompt('Please enter your age')
// console.log(age)


//diff between var, let and const


// var myName = 'John'
// console.log(myName)

//constants
//use const if variables are constants .
//They cannnot be reassigned

// const birthday = '10/02/2000'
// //100 lines of code

// birthday = '11/01/1995'


//interaction
//alert , prompt, confirm

// let isProgrammer = confirm('Are you a programmer?')
// console.log(isProgrammer)


















