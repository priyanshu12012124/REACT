

function Greetings() {

    return <h1>Hi All</h1>
}

export default Greetings
